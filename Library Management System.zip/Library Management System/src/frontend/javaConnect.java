/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frontend;

import java.sql.*;

/**
 *
 * @author OMIKUNLE ABDULKAREEM
 */
public class javaConnect {
    
    static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/librarymanagement";
    static final String USER = "hbstudent";
    static final String PASS = "hbstudent";
   
    
public static Connection connectDb(){
      Connection conn = null;
        try{
            // registered jdbc Driver, not required for newer version of jdk
            //Class.forName("com.mysql.jdbc.Driver");
            //Open a onnection
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            return conn;
            
        }catch (Exception ex){
            System.out.println("There were errors while connecting the db.");
            return null;
        }
}
    
}
